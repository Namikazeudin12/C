// SETING SESUAIN AJA YANG UDAH DI KASIH KOMEN
const fs = require('fs')
const chalk = require('chalk')
const axios = require("axios");

global.owner = ['6285760162586'] // ganti nomor lu
global.packname = 'Vyzz Botz' // ganti bebas
global.author = 'Vyzter Impact' // ganti bebas



// 👇  Daftar di https://panel.lapaksosmed.com dan ambil api_id ama apikeynya ganti jangan hapus tanda " "
global.api_id = "300684" // ganti api id
global.api_key = "TXsF0s53gzbLd56ybuImJQMAoI9wrqrY" // api key




// 👇 Daftar di https://famsosmed.com ambil apikey nya aja
global.keyUrl = "https://famsosmed.com/api/v1" // gausah diganti
global.keyApi = 'gFRr5UOvEnzxtTdiaN8CiYtRmCsClOlRHLbv2xRPoVe8nMflsUB5nHqTYrahGeDEojWg0sIXlNiqru09F7frKgSzYQtzw6CIy8trxqkby6gC75x2ydw86QJe' // ganti apikey


require("./sunTik")
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.blueBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})